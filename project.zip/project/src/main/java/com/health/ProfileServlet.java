package com.health;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String email = (String) session.getAttribute("email");

        if (email == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String name = "", phoneNumber = "", bmiResult = "", diet = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "Sai@522410");
            PreparedStatement ps = con.prepareStatement("SELECT name, phone_number FROM user WHERE email = ?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                name = rs.getString("name");
                phoneNumber = rs.getString("phone_number");
            }

            ps = con.prepareStatement("SELECT bmi FROM bmi WHERE email = ?");
            ps.setString(1, email);
            rs = ps.executeQuery();
            if (rs.next()) {
                double bmi = rs.getDouble("bmi");
                bmiResult = String.format("%.2f", bmi);
                if (bmi < 18.5) {
                    diet = "Increase calorie intake with nutrient-dense foods, focus on protein-rich foods, include healthy fats, and eat small, frequent meals.";
                } else if (bmi < 25) {
                    diet = "Maintain a balanced diet with a variety of foods, focus on whole grains, lean proteins, fruits, and vegetables.";
                } else if (bmi < 30) {
                    diet = "Focus on portion control and reducing calorie intake, increase intake of fruits, vegetables, and whole grains, limit high-calorie snacks.";
                } else {
                    diet = "Follow a structured meal plan to reduce calorie intake, prioritize low-calorie, nutrient-dense foods, limit processed foods.";
                }
            }
            rs.close();
            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("name", name);
        request.setAttribute("phoneNumber", phoneNumber);
        request.setAttribute("bmiResult", bmiResult);
        request.setAttribute("diet", diet);
        request.getRequestDispatcher("profile.jsp").forward(request, response);
    }
}
