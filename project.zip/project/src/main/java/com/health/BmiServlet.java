package com.health;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/BmiServlet")
public class BmiServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String email = (String) session.getAttribute("email");

        if (email == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        double weight = Double.parseDouble(request.getParameter("weight"));
        double height = Double.parseDouble(request.getParameter("height"));
        double bmi = weight / (height * height);

        String diet = "";

        if (bmi < 18.5) {
            diet = "Increase calorie intake with nutrient-dense foods, focus on protein-rich foods, include healthy fats, and eat small, frequent meals.";
        } else if (bmi < 25) {
            diet = "Maintain a balanced diet with a variety of foods, focus on whole grains, lean proteins, fruits, and vegetables.";
        } else if (bmi < 30) {
            diet = "Focus on portion control and reducing calorie intake, increase intake of fruits, vegetables, and whole grains, limit high-calorie snacks.";
        } else {
            diet = "Follow a structured meal plan to reduce calorie intake, prioritize low-calorie, nutrient-dense foods, limit processed foods.";
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "Sai@522410");

            PreparedStatement ps = con.prepareStatement("INSERT INTO bmi (email, bmi) VALUES (?, ?) ON DUPLICATE KEY UPDATE bmi = ?");
            ps.setString(1, email);
            ps.setDouble(2, bmi);
            ps.setDouble(3, bmi);
            ps.executeUpdate();

            session.setAttribute("bmi", bmi);
            session.setAttribute("diet", diet);
            con.close();
            response.sendRedirect("bmiResult.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
